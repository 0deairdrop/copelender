Demo: https://iamibrahimriaz.github.io/geex-html/

# HTML version of Hexadash dashboard
## Project setup
```
npm install or yarn install
```
```
gulp install
```

### Compiles for development
```
Gulp
```

### Compiles and minifies for RTL
```
Gulp rtl
```
