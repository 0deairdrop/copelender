<?php
// TABLES
const DEF_TBL_USR_USERS = "usr_users";
const DEF_TBL_USR_PASSWORD_RESET = "usr_password_reset";
const DEF_TBL_USR_ACTIVATION = "usr_user_activation";


