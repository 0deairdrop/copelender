<?php
// database connection 
define('DB_SERVER_LIVE', 'localhost');
define('DB_NAME_LIVE', 'poshdvzy_laworex');
define('DB_USERNAME_LIVE', 'poshdvzy_iyiolastrings');
define('DB_PASSWORD_LIVE', 'Olaoluwaiyiola14@');
define('DB_SERVER_LOCAL', 'localhost');

define('DB_NAME_LOCAL', 'copelender');
define('DB_USERNAME_LOCAL', 'root');
define('DB_PASSWORD_LOCAL','');

