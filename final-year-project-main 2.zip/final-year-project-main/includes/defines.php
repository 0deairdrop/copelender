<?php
/**
 * Constants
 */
const APP_NAME = 'Coplender';


/**
 * Modules
 */
const DEF_MODULE_ID_AUTH = 150;
const DEF_MODULE_ID_REFRESH_TOKEN = 151;
const DEF_MODULE_ID_USER = 160;

